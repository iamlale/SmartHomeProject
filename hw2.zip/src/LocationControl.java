public interface LocationControl {

    public void onLeave();
    public void onCome();
}
