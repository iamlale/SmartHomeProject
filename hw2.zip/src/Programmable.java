public interface Programmable {

    public void setTimer(int seconds);
    public void cancelTimer();
    public void runProgram();
}
