public interface MotionControl {

     boolean controlMotion( boolean hasMotion, boolean isDay);

}
