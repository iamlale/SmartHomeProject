
public interface Comparable <SmartCamera>{
}
